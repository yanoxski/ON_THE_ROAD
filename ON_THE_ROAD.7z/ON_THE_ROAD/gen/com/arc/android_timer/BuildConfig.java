/** Automatically generated file. DO NOT MODIFY */
package com.arc.android_timer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}